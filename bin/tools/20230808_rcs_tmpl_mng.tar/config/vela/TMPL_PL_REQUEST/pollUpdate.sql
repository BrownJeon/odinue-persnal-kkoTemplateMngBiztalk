/* dotask.TMPL_PL_REQUEST.ftl pollUpdate */
UPDATE 
   RCS_TMPL_MNG
SET
    STEP = '2'
    , APPROVAL_RESULT = '���δ��'
    , POLLING_DATE = @�����Ͻ�
    , POLLKEY = @����Ű
WHERE 
    STEP = '1'
    AND REGIST_DATE > TO_CHAR(sysdate-3, 'YYYYMMDDHH24MISS')
    AND REGIST_DATE <= TO_CHAR(sysdate, 'YYYYMMDDHH24MISS')
    AND ROWNUM < @countFetch