/* dotask.TMPL_DBX.ftl updateTemplateRbcFormParam */
 UPDATE
    RCS_TMPL_MNG
SET
    FORM_PARAM = @�����ٵ�
WHERE
    SEQ = @SEQ